MSVC Project
====
The solution has been created with Visual Studio Express 2010.
Preliminary project for testing windows compatibility.
It do not come with a warranty.
