This folder is part of dmlc-core library, this allows rabit to use unified stream interface with other dmlc projects.

- Since it is only interface dependency DMLC core is not required to compile rabit
- To compile project that uses dmlc-core functions, link to libdmlc.a (provided by dmlc-core) will be required.
